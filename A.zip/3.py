def Matrix_Mul(Mat, m):   
    def multiply_matrices(M1, M2):
        size = len(M1)
        result = [[0] * size for _ in range(size)]
        for i in range(size):
            for j in range(size):
                for k in range(size):
                    result[i][j] += M1[i][k] * M2[k][j]
        return result    
    if m == 1:
        return Mat
    return multiply_matrices(Mat, Matrix_Mul(Mat, m - 1)) 
Mat = [[1, 2, 3], [2, 4, 5], [4, 7, 9]]
m = 3
result = Matrix_Mul(Mat, m)
print(f"Original Matrix:{Mat}")
print(f"\nMatrix raised to power {m}: {result}")
 
