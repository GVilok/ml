count = 0
List  = [2,7,4,1,3,6]
n = len(List)

for i in range(n):
    for j in range(i-1):
         x = List[j]+List[i]
         if x == 10 :
             count = count+1

print(count)              