def bubblesort(arr):
      for n in range(len(arr) - 1, 0, -1):          
        for i in range(n):
            if arr[i] > arr[i + 1]:          
                arr[i], arr[i + 1] = arr[i + 1], arr[i]             
                 
      return arr           
a = []
n = int(input("Enter the number of elements: "))
if n < 3:
    print("range determiantion is not possible")
else:    
    for i in range(n):
        element = int(input(f"Enter element {i + 1}: "))
        a.append(element)
a = bubblesort(a)
print(a)
print(f"range({a[0]}-{a[n-1]})")