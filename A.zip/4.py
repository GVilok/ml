def Main(S):
   
    dic ={}
    
    for i in range(len(S)):
        if S[i] in dic:
            dic[S[i]] += 1   
        else:
            dic[S[i]] = 1   
    
    return dic


D = Main("hippopotamus")


X = max(D, key = D.get)

print(f"{X} with accurance value of {D[X]}")
    
    
            
                
                
                
        
        