import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier

# Load the dataset
data = pd.read_csv("employee_data.csv", encoding="utf-8")

# Split into categories based on Gender
category_x = data[data["Gender"] == 0]  # Male
category_y = data[data["Gender"] == 1]  # Female

# Select numeric columns
numeric_columns = data.select_dtypes(include=[np.number]).columns
data_x = category_x[numeric_columns]
data_y = category_y[numeric_columns]

# Compute centroids and spreads
centroid_x = data_x.mean(axis=0)
centroid_y = data_y.mean(axis=0)
spread_x = data_x.std(axis=0)
spread_y = data_y.std(axis=0)

distance = np.linalg.norm(centroid_x - centroid_y)

print("Centroid of Category X (Male):", np.array(centroid_x))
print("Centroid of Category Y (Female):", np.array(centroid_y))
print("Spread of Category X (Male):", np.array(spread_x))
print("Spread of Category Y (Female):", np.array(spread_y))
print("Interclass Distance between Male and Female groups:", distance)

# Histogram for Age
selected_feature = data["Age"]

def compute_statistics(feature_column):
    avg_value = np.mean(feature_column)
    var_value = np.var(feature_column)
    return avg_value, var_value

def draw_histogram(values, num_bins):
    plt.hist(values, bins=num_bins, edgecolor="black")
    plt.show()

draw_histogram(selected_feature, 5)

stat_results = compute_statistics(selected_feature)
print("Mean of the selected feature:", stat_results[0])
print("Variance of the selected feature:", stat_results[1])

# Minkowski Distance Calculation
feature1 = data["Age"]
feature2 = data["Weekly_Work_Hours"]

def minkowski_distance(vec1, vec2, r):
    return np.linalg.norm(vec1 - vec2, ord=r)

r_values = range(1, 11)
distances = [minkowski_distance(feature1, feature2, r) for r in r_values]

plt.plot(r_values, distances, marker="o", linestyle="-", color="b")
plt.xlabel("Order of Minkowski Distance (r)")
plt.ylabel("Distance Value")
plt.title("Minkowski Distance for Different r Values")
plt.grid()
plt.show()

# Preparing Data for KNN
numeric_data = ["Age", "Id", "Weekly_Work_Hours"]
X = data[numeric_data]
y = data["Gender"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

print("Training Set Shape (X_train):", X_train.shape)
print("Testing Set Shape (X_test):", X_test.shape)
print("Training Labels Shape (y_train):", y_train.shape)
print("Testing Labels Shape (y_test):", y_test.shape)

# KNN Classifier
neigh = KNeighborsClassifier(n_neighbors=3)
neigh.fit(X_train, y_train)

# Model Accuracy
score = neigh.score(X_test, y_test)
print("Accuracy Score:", score)

# Predictions
y_predict = neigh.predict(X_test)
print("First 15 Predicted Labels:", y_predict[:15])
print("First 15 Actual Labels:", y_test.values[:15])

# KNN Accuracy for Different k values
k_values = range(1, 12)
accuracy = []
for k in k_values:
    knn = KNeighborsClassifier(n_neighbors=k)
    knn.fit(X_train, y_train)
    acc = knn.score(X_test, y_test)
    accuracy.append(acc)

plt.figure(figsize=(8, 5))
plt.plot(k_values, accuracy, marker='o', linestyle='-', color='b', label="Accuracy")
plt.xlabel("Number of Neighbors (k)")
plt.ylabel("Accuracy Score")
plt.title("k-NN Accuracy for Different k Values")
plt.xticks(k_values)
plt.legend()
plt.show()

# Confusion Matrix and Classification Report
from sklearn.metrics import confusion_matrix, classification_report

y_train_pred = neigh.predict(X_train)
y_test_pred = neigh.predict(X_test)

train_cm = confusion_matrix(y_train, y_train_pred)
test_cm = confusion_matrix(y_test, y_test_pred)

print("Confusion Matrix (Training Data):\n", train_cm)
print("Confusion Matrix (Test Data):\n", test_cm)

print("\nClassification Report (Training Data):\n", classification_report(y_train, y_train_pred))
print("\nClassification Report (Test Data):\n", classification_report(y_test, y_test_pred))
