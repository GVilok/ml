import pandas as pd
import numpy as np
import statistics as stat
import math
import matplotlib.pyplot as plt

df=pd.read_excel("Lab_Session_Data.xlsx",sheet_name=1)
# A4 -1
m=stat.mean(df['Price'])
v=stat.variance(df['Price'])
print("Mean of Prices: ",m)
print("Mean of Prices: ",v)

# A4 -2
t_day="Wed"
d_row=df[df['Day']==t_day]
# print(row)
d_cost=stat.mean(d_row['Price'])
print("Mean Cost on Wednesday: ",d_cost)
cmp_mean=d_cost-m
if cmp_mean<0:
    print("Cost is lower on Wednesday than overall mean: ",math.fabs(cmp_mean))
else:
    print("Cost is higher on Wednesday than overall mean: ",math.fabs(cmp_mean))

# A4 -3
t_month="Apr"
m_row=df[df['Month']==t_month]
m_cost=stat.mean(m_row['Price'])
cmp_month_mean=m_cost-m
if cmp_month_mean<0:
    print("Cost is lower during April than overall mean: ",math.fabs(cmp_month_mean))
else:
    print("Cost is higher during April than overall mean: ",math.fabs(cmp_month_mean))

# A4-4
# Loss Probability
# Its important to check data type before performing calculation
print(df['Chg%'].dtype) # The output here is float-type.
# Hence we don't need type-casting
# Calculates Loss Prob = (freq(loss)/total(observations))
lossp=(lambda x: sum(x<0)/len(x))(df['Chg%'])
print(f"Probability of loss occurance: {lossp:.3f}")

# A4-5
# Probability of profit on Wednesday
# Approach - Select rows which have day as Wednesday
# Then from those rows check the value of them in Chg% column
# Find the frequency of positive growth rates
# Divide by total number of rows

wed_data=df[df['Day']=="Wed"]
total_days=len(df)
profit_wed=(lambda x: sum(x>0)/total_days)(wed_data['Chg%'])
print(f"Probability of profit on Wednesday: {profit_wed:.3f}")

# A4-6
# Small change instead of dividing by all days data we have to divide by total number of wednesdays
cond_profit_wed=(lambda x: sum(x>0)/len(x))(wed_data['Chg%'])
print(f"Probability of profit on Wednesday (Conditional Case): {cond_profit_wed:.3f}")

# A4-7
plt.figure(figsize=(8, 5))
plt.scatter(df['Chg%'], df['Day'], marker='o', linestyle='-', color='red')
plt.xlabel('Stock Price Growth Rate')
plt.xlabel('Day of the week')
plt.title("Stock Price Growth Rate v/s Day of the week")
plt.show()