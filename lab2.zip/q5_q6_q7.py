import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler

df=pd.read_excel('Lab_Session_Data.xlsx',sheet_name=2)

 
df.replace("?", np.nan, inplace=True)
num_cols = df.select_dtypes(include=[np.number]).columns.tolist()
cat_cols = df.select_dtypes(include=["object"]).columns.tolist()
print("\nNumerical columns:", num_cols)
print("Categorical columns:", cat_cols)

 
encoded_df=df
binary_cols = [col for col in cat_cols if df[col].nunique() == 2]
for col in binary_cols:
    encoded_df[col] = encoded_df[col].map({"t": 1, "f": 0, "F": 0, "M":1 })

nominal_cols = list(set(cat_cols) - set(binary_cols))
encoded_df = pd.get_dummies(df, columns=nominal_cols, drop_first=True)

print("\nData after encoding:")
print(encoded_df.head())

 
num_ranges = df[num_cols].agg(["min", "max"])
print("\nRange of numerical values:")
print(num_ranges)


#4
missing_values = df.isnull().sum()
print("\nMissing values per column:")
print(missing_values[missing_values > 0])

#5
def detect_outliers(col):
    Q1 = df[col].quantile(0.25)
    Q3 = df[col].quantile(0.75)
    IQR = Q3 - Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    return df[(df[col] < lower_bound) | (df[col] > upper_bound)][col]

outliers = {col: detect_outliers(col) for col in num_cols}
print("\nOutliers detected:")
for col, outlier_vals in outliers.items():
    if not outlier_vals.empty:
        print(f"{col}: {outlier_vals.values}")

#6
mean_values = df[num_cols].mean()
variance_values = df[num_cols].var()
std_values = df[num_cols].std()

print("\nMean values:")
print(mean_values)
print("\nVariance values:")
print(variance_values)
print("\nStandard deviation values:")
print(std_values)

#A6
 
for col in num_cols:
    if col in outliers and not outliers[col].empty:
        df[col] = df[col].fillna(df[col].median())   
    else:
        df[col] = df[col].fillna(df[col].mean())  

 
for col in cat_cols:
    df[col] = df[col].fillna(df[col].mode()[0])  


#A7
scaler = MinMaxScaler()  

df[num_cols] = scaler.fit_transform(df[num_cols])

print("Data after normalization:")
print(df.head())

