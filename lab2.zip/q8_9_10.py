import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from scipy.spatial.distance import cosine

def compute_dependents(v1, v2):
    m11 = np.sum((v1 == 1) & (v2 == 1))
    m00 = np.sum((v1 == 0) & (v2 == 0))
    m10 = np.sum((v1 == 1) & (v2 == 0))
    m01 = np.sum((v1 == 0) & (v2 == 1))
    return [m11, m00, m10, m01]

def compute_jc_smc(v1, v2):
    calc = compute_dependents(v1, v2)
    jc = calc[0] / (calc[0] + calc[2] + calc[3]) if (calc[0] + calc[2] + calc[3]) != 0 else 0
    smc = (calc[0] + calc[1]) / sum(calc) if sum(calc) != 0 else 0
    return jc, smc

def compute_pairwise(df_subset, n):
    jc_matrix = np.zeros((n, n))
    smc_matrix = np.zeros((n, n))
    cos_matrix = np.zeros((n, n))
    
    for i in range(n):
        for j in range(n):
            if i == j:
                jc_matrix[i, j] = 1
                smc_matrix[i, j] = 1
                cos_matrix[i, j] = 1
            else:
                v1, v2 = df_subset[i], df_subset[j]
                jc, smc = compute_jc_smc(v1, v2)
                cos_sim = 1 - cosine(v1, v2)
                jc_matrix[i, j] = jc
                smc_matrix[i, j] = smc
                cos_matrix[i, j] = cos_sim
    return jc_matrix, smc_matrix, cos_matrix

def plot_heatmap(matrix, title):
    plt.figure(figsize=(10, 8))
    sns.heatmap(matrix, annot=True, fmt=".2f", cmap="coolwarm")
    plt.title(title)
    plt.xlabel("Observation Vectors")
    plt.ylabel("Observation Vectors")
    plt.show()

df = pd.read_excel('Lab_Session_Data.xlsx', sheet_name=2)
df = df.replace({"t": 1, "f": 0})
df = df.apply(pd.to_numeric, errors='coerce').fillna(0)
df_subset = df.iloc[:20].values
n = len(df_subset)

jc_matrix, smc_matrix, cos_matrix = compute_pairwise(df_subset, n)

plot_heatmap(jc_matrix, "Jaccard Coefficient Heatmap")
plot_heatmap(smc_matrix, "Simple Matching Coefficient Heatmap")
plot_heatmap(cos_matrix, "Cosine Similarity Heatmap")

r1, r2 = df.iloc[0].values, df.iloc[1].values
cos_sim = 1 - cosine(r1, r2)
print("Cosine Similarity:", cos_sim)
calc = compute_dependents(r1, r2)
jc, smc = compute_jc_smc(r1, r2)
print("Jaccard Score:", jc)
print("SMC for 2 vectors:", smc)
