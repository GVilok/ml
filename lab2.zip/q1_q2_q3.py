import pandas as pd
import numpy as np

 
data = pd.read_excel('Lab_Session_Data.xlsx')
data_selected = data.iloc[:, 1:5]

 
A = data_selected.iloc[:, 0:3].values
C = data_selected.iloc[:, 3].values

 
print("Shape of A:", np.shape(A))
print("Shape of C:", np.shape(C))
print("Rows in A:", len(A))
print("Rows in C:", len(C))

 
print("Rank of A:", np.linalg.matrix_rank(A))

 
A_pinv = np.linalg.pinv(A)
print("Shape of pseudo-inverse of A:", A_pinv.shape)
print("Pseudo-inverse of A:", A_pinv)

 
X = np.dot(A_pinv, C)
print("Shape of X:", X.shape)
print("Values of X:", X)

 
data_selected['Cost_Effectiveness'] = data_selected['Payment (Rs)'].apply(lambda x: 'Rich' if x > 200 else 'Poor')

 
data_selected.to_excel('Updated_Purchase_Data.xlsx', index=True)
updated_data = pd.read_excel('Updated_Purchase_Data.xlsx')

 
print(updated_data.iloc[:, 1:6])
