import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error, mean_absolute_percentage_error, r2_score

# Load the dataset
data = pd.read_excel('Lab_Session_Data.xlsx')
data_selected = data.iloc[:, 1:5]

# Define features (A) and target (C)
A = data_selected.iloc[:, 0:3].values
C = data_selected.iloc[:, 3].values

 
A_pinv = np.linalg.pinv(A)
X = np.dot(A_pinv, C)

 
C_pred = np.dot(A, X)

mse = mean_squared_error(C, C_pred)
rmse = np.sqrt(mse)
mape = mean_absolute_percentage_error(C, C_pred)
r2 = r2_score(C, C_pred)

# Print results
print(f"MSE: {mse}")
print(f"RMSE: {rmse}")
print(f"MAPE: {mape}")
print(f"R² Score: {r2}")

data_selected['Cost_Effectiveness'] = data_selected['Payment (Rs)'].apply(lambda x: 'Rich' if x > 200 else 'Poor')

# Save updated data
data_selected.to_excel('Updated_Purchase_Data.xlsx', index=False)

 
np.random.seed(42)   
X = np.random.uniform(1, 10, 20)
Y = np.random.uniform(1, 10, 20)

 
classes = np.where(X + Y > 10, 1, 0)   

 
plt.figure(figsize=(8, 6))
for i in range(20):
    color = 'red' if classes[i] == 1 else 'blue'
    plt.scatter(X[i], Y[i], color=color, edgecolors='black')

plt.xlabel('Feature X')
plt.ylabel('Feature Y')
plt.title('Scatter Plot of Generated Data')
plt.grid(True)
plt.show()
