import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import confusion_matrix, classification_report

# Load 
data = pd.read_csv("employee_data.csv", encoding="utf-8")

# Select  
data_filtered = data[data["Gender"].isin([0, 1])]  # Consider only Male (0) & Female (1)
selected_features = ["Age", "Weekly_Work_Hours"]
X = data_filtered[selected_features]
y = data_filtered["Gender"]

# Split  
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Training 
knn = KNeighborsClassifier(n_neighbors=3)
knn.fit(X_train, y_train)

# Predictions
y_pred = knn.predict(X_test)

# Performance Evaluation
print("Confusion Matrix:")
print(confusion_matrix(y_test, y_pred))
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

# Hyperparameter tuning using GridSearchCV
param_grid = {'n_neighbors': np.arange(1, 21), 'metric': ['euclidean', 'manhattan', 'minkowski']}
grid_search = GridSearchCV(KNeighborsClassifier(), param_grid, cv=5, scoring='accuracy')
grid_search.fit(X_train, y_train)

# Best parameters
print("Best Parameters:", grid_search.best_params_)
print("Best Accuracy:", grid_search.best_score_)

# Plot Accuracy for Different k Values
k_values = np.arange(1, 21)
accuracy = [grid_search.cv_results_['mean_test_score'][i] for i in range(len(k_values))]
plt.figure(figsize=(8, 5))
plt.plot(k_values, accuracy, marker='o', linestyle='-', color='b', label="Accuracy")
plt.xlabel("Number of Neighbors (k)")
plt.ylabel("Accuracy Score")
plt.title("k-NN Accuracy for Different k Values")
plt.xticks(k_values)
plt.legend()
plt.show()


 