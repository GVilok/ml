import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

 
np.random.seed(42)
data_size = 100
feature_1 = np.random.uniform(10, 100, data_size)
feature_2 = np.random.uniform(5, 50, data_size)

 
df = pd.DataFrame({'Feature_1': feature_1, 'Feature_2': feature_2})

 
mean_f1, var_f1 = np.mean(feature_1), np.var(feature_1)
mean_f2, var_f2 = np.mean(feature_2), np.var(feature_2)

print(f"Feature 1 - Mean: {mean_f1}, Variance: {var_f1}")
print(f"Feature 2 - Mean: {mean_f2}, Variance: {var_f2}")

 
plt.figure(figsize=(12, 5))

 
plt.subplot(1, 2, 1)
plt.hist(feature_1, bins=10, edgecolor="black", alpha=0.7)
plt.xlabel("Feature 1 Values")
plt.ylabel("Frequency")
plt.title("Histogram of Feature 1")

 
plt.subplot(1, 2, 2)
plt.scatter(feature_1, feature_2, color="blue", edgecolors="black")
plt.xlabel("Feature 1")
plt.ylabel("Feature 2")
plt.title("Scatter Plot of Features")

plt.tight_layout()
plt.show()
